"use strict"; // prevent lazy programming in JavaScript :)

// URL for dataFile
var URL = "Script/DataOpti.json"

// DOM Ready event, after DOM is loaded compledly
// every time if the DOM refresh
$(document).ready(function() {
	
	S7Framework.initAuto("#loading_div", $.init);
} );

$.init = function(){
	
	// read Values first time
	S7Framework.readData(URL, "init read data", deployValues);
	
	//EVENTHANDLING 
	// START Button
	// START Button
	$("#startButton").click(function(){
		var data = '"Web2Plc".start=1'+'&'+'"Web2Plc".stop=0';
		S7Framework.writeData(URL, data, "START");
	});
	
	// STOP Button
	$("#stopButton").click(function(){
		var data = '"Web2Plc".start=0'+'&'+'"Web2Plc".stop=1';
		S7Framework.writeData(URL, data, "STOP");
	})
}


// function to deploy values into Webpage
function deployValues(values)
{
	/* var data = values.data.split(","); */
	var select = "table[id='dataTable'] tbody tr";
	$(select).each(function(index){
		if(index < values.length/2){
			$(this).find('td').eq(1).html( values[2*index+1] );
			$(this).find('td').eq(2).html( values[2*index] );
		}
		else{
			$(this).closest('tr').hide();
		}
	});
	// read Values cyclically
	setTimeout(S7Framework.readData(URL, "init read data", deployValues), 1000);
}
