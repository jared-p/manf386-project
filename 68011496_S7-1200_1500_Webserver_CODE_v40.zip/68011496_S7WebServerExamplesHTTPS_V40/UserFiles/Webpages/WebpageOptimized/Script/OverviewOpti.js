"use strict"; // prevent lazy programming in JavaScript :)

// image array for valve image
var img_array = new Array();
img_array[0] = new Image();
img_array[0].src = "Images/Valve0.png"; // OFF
img_array[0].alt = "Valve := Closed"; // OFF
img_array[1] = new Image();
img_array[1].src = "Images/Valve1.png"; // ON
img_array[1].alt = "Valve := Open"; // ON

// Arrays for Alarm messag and Text color
var alarmArrayText = new Array(
	"Tank empty!",
	"Tank level below minimum!",
	"Tank level between minimum and midth!",
	"Tank level between midth and maximum!",
	"Tank level over maximum!",
	"Tank level overflow!"
	);
var alarmArrayColor = new Array(
	"red",
	"yellow",
	"black",
	"green"
);

// URL for dataFile
var URL = "Script/OverviewOpti.json"

// every time if the DOM refresh
$(document).ready(function() {
	
	S7Framework.initAuto("#loading_div", $.init);
} );

$.init = function(){
	
	// read Values first time
	S7Framework.readData(URL, "init read data", deployValues);
	
	//EVENTHANDLING 
	// Open Valve Button
	$("#openValve").click(function(){
		var data = '"Web2Plc".openValve=1'+'&'+'"Web2Plc".closeValve=0';
		S7Framework.writeData(URL, data, "OPEN VALVE");
	});
	
	// Close Valve Button
	$("#closeValve").click(function(){
		var data = '"Web2Plc".openValve=0'+'&'+'"Web2Plc".closeValve=1';
		S7Framework.writeData(URL, data, "CLOSE VALVE");
	})
	
	// START Button
	$("#startButton").click(function(){
		var data = '"Web2Plc".start=1'+'&'+'"Web2Plc".stop=0';
		S7Framework.writeData(URL, data, "START");
	});
	
	// STOP Button
	$("#stopButton").click(function(){
		var data = '"Web2Plc".start=0'+'&'+'"Web2Plc".stop=1';
		S7Framework.writeData(URL, data, "STOP");
	})
}


// function to deploy values into Webpage
function deployValues(values)
{
	var img;
	if (values[0] == false)
	{
		img = 0;
	}
	else
	{
		img = 1;
	}
	
	$('#statusValveCPU').attr({
		src: img_array[ img ].src,
		title: img_array[ img ].alt,
		alt: img_array[ img ].alt
	});
	
	$('#tankLevelScaleOverviewImg').height( values[1] + "px");
	
	$('#actFlowrate').html( values[2] );
	$('#tankLevel').html( values[3] );
	$('#tankLevelOverflow').html( values[4] );
	$('#tankLevelMaximum').html( values[5] );
	$('#tankLevelMidth').html( values[6] );
	$('#tankLevelMinimum').html( values[7] );
	$('#tankLevelLack').html( values[8] );
	
	
	$('#Alarm')
		.html( alarmArrayText[values[9]] )
		.css('color', alarmArrayColor[values[10]]);
		
	// read Values cyclically
	setTimeout(S7Framework.readData(URL, "init read data", deployValues), 1000);
}
