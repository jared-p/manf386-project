"use strict"; // prevent lazy programming in JavaScript :)

// image array for plantStatus image
var img_array = new Array();
img_array[0] = new Image();
img_array[0].src = "Images/Status00.png"; // OFF
img_array[0].alt = "Plant Status := OFF"; // OFF
img_array[1] = new Image();
img_array[1].src = "Images/Status01.png"; // ON
img_array[1].alt = "Plant Status := ON"; // ON

// URL for dataFile
var URL = "Script/StartOpti.json"

// every time if the DOM refresh
$(document).ready(function() {
	
	S7Framework.initAuto("#loading_div", $.init);
} );

$.init = function(){
	
	// read Values first time
	S7Framework.readData(URL, "init read data", deployValues);
	
	//EVENTHANDLING 
	// START Button
	$("#startButton").click(function(){
		var data = '"Web2Plc".start=1'+'&'+'"Web2Plc".stop=0';
		S7Framework.writeData(URL, data, "START");
	});
	
	// STOP Button
	$("#stopButton").click(function(){
		var data = '"Web2Plc".start=0'+'&'+'"Web2Plc".stop=1';
		S7Framework.writeData(URL, data, "STOP");
	})
	
	// RESET Button
	$("#resetButton").click(function(){
		var data = '"Web2Plc".reset=1';
		S7Framework.writeData(URL, data, "RESET");
	})
	
	// FLOWRATE Button
	$("#flowrateButton").click(function(){
		var flowrate = $("#flowrate").val();
		if ( (flowrate >= 1 && flowrate <= 10 ) == false)
		{
			alert("Value must be between 1 and 10!");
			return;
		}
		else{
			var data = '"Web2Plc".flowrate=' + flowrate;
			S7Framework.writeData(URL, data, "FLOWRATE");
		}
	})
}


// function to deploy values into Webpage
function deployValues(values)
{
	var img;
	if (values[0] == false)
	{
		img = 0;
	}
	else
	{
		img = 1;
	}
	
	$('#plantStatus').attr({
		src: img_array[ img ].src,
		title: img_array[ img ].alt,
		alt: img_array[ img ].alt
	});
	
	$('#actFlowrate').html( values[1] );
	$('#tankLevelScale').html( values[2] );
	$('#tankLevelScaleImg').width( values[2] + "%");

	// read Values cyclically
	setTimeout(S7Framework.readData(URL, "init read data", deployValues), 1000);
}
