var hostAddress= null;
var userToken = null;

// image array for plantStatus image
var img_status_array = new Array();
img_status_array[0] = new Image();
img_status_array[0].src = "Images/Status00.png"; // OFF
img_status_array[0].alt = "Plant Status := OFF"; // OFF
img_status_array[1] = new Image();
img_status_array[1].src = "Images/Status01.png"; // ON
img_status_array[1].alt = "Plant Status := ON"; // ON

// image array for valve image
var img_valve_array = new Array();
img_valve_array[0] = new Image();
img_valve_array[0].src = "Images/Valve0.png"; // OFF
img_valve_array[0].alt = "Valve := Closed"; // OFF
img_valve_array[1] = new Image();
img_valve_array[1].src = "Images/Valve1.png"; // ON
img_valve_array[1].alt = "Valve := Open"; // ON

// Arrays for Alarm message and Text color
var alarmArrayText = new Array(
	"Tank empty!",
	"Tank level below minimum!",
	"Tank level between minimum and midth!",
	"Tank level between midth and maximum!",
	"Tank level over maximum!",
	"Tank level overflow!"
	);
var alarmArrayColor = new Array(
	"red",
	"yellow",
	"black",
	"green"
);


$(document).ready(function(){
	var urlParameter = getUrlParameter();
	var tokenParam = urlParameter["userToken"];
	var hostParam = urlParameter["hostAddress"];
	if (tokenParam && hostParam)
	{
		userToken = tokenParam;
		hostAddress = hostParam;

		updateWebpage();
	}
	else {
		$('#plcLoginContainer').show();
		$('#plcTankContainer').hide();
	}
	
	window.onerror = function (message, source, lineno, colno, error) {
		toastr.error(message, "Error", { "timeOut": "0"});
	};
	
	//EVENTHANDLING 
	// START Button
	$("#startButton").click(function(){
		writeStart();
	});
	
	// STOP Button
	$("#stopButton").click(function(){
		writeStop();
	})
	
	// RESET Button
	$("#resetButton").click(function(){
		writeReset();
	})
	
	// Open Valve Button
	$("#openValve").click(function(){
		writeOpenValve();
	});
	
	// Close Valve Button
	$("#closeValve").click(function(){
		writeCloseValve();
	})
	
	// FLOWRATE Button
	$("#flowrateButton").click(function(){
		var flowrate = $("#flowrate").val();
		if ( (flowrate >= 1 && flowrate <= 10 ) == false)
		{
			alert("Value must be between 1 and 10!");
			return;
		}
		else{
			writeFlowrate(flowrate);
		}
	})

});

function getUrlParameter() {
    var parameter = {};
    window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(match,key,value) {
        parameter[key] = value;
    });
    return parameter;
}

function updateWebpage(){
	$('#plcLoginContainer').hide();
	$('#plcTankContainer').show();
	
	if(document.getElementById('overviewLink')){
		document.getElementById('overviewLink').setAttribute("href", "OverviewApi.html?userToken=" + userToken + "&hostAddress=" + hostAddress);
	}
	else {
		setTimeout(readValuesOverview, 1000);
	}
	if(document.getElementById('dataLink')){
		document.getElementById('dataLink').setAttribute("href", "DataApi.html?userToken=" + userToken + "&hostAddress=" + hostAddress);
	}
	else {
		setTimeout(readValuesData, 1000);
	}
	if(document.getElementById('startLink')){
		document.getElementById('startLink').setAttribute("href", "StartApi.html?userToken=" + userToken + "&hostAddress=" + hostAddress);
	}
	else {
		setTimeout(readValuesStart, 1000);
	}

}

function successCallbackLogin(data){
			var obj = JSON.parse(data);
			if(obj && obj.result) {
				userToken = obj.result.token;
				$('#plcLoginToken').html(userToken);
				updateWebpage();
			} 
		}

function login(){
	if(!hostAddress){
		hostAddress = $('#plcIpAdress').val();
	}

	var username = $('#webServerUserName').val();
	var password = $('#webServerUserpassword').val();
	if(hostAddress && username){
		var request = {
			id: "888",
			jsonrpc: "2.0",
			method: "Api.Login",
			params: {
				user: username,
				password: password || ''
			}
		};
		
		postJsonRPC(hostAddress, request, userToken, successCallbackLogin); 
	}
	else{
		toastr.warning('Please provide the PLC IP Adress/Username/Password', 'Warning', {timeOut: 2000});                    
	}
	
}


toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": false,
    "positionClass": "toast-top-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "5000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
  }

function postJsonRPC(host, request, token, successCallback, errorCallBack) {
	
    if(host && request && (token || (request.method && request.method.toLowerCase().indexOf('api.login') != -1))){
        var api = "https://"+ host +"/api/jsonrpc";
	
        // Send request
        $.ajax({
            type: "POST",
            url: api,
            headers: {
                'X-Auth-Token': token
            },
            data: JSON.stringify(request),
            dataType: "text",
            contentType: "application/json",
            success: function (data, textStatus, jqXHR) {
                if(successCallback)
                    successCallback(data, textStatus, jqXHR);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if(errorCallBack)
                    errorCallBack(jqXHR, textStatus, errorThrown);
                else {
                    toastr.error("Error occured while making the POST request. Please check the browser console for more details.", "Error", {timeOut: 2000});
                    console.log(errorThrown);
                }                
            }
        });
        
        // Print request
        console.log("REQUEST: " + JSON.stringify(request));
    }
    else{
        if(!host)
            toastr.warning("Please provide the PLC IP Address.", "Warning", {timeOut: 2000});
        else if(!request || (request && !request.method))
            toastr.warning("Please provide a valid API End Point.", "Warning", {timeOut: 2000});
        else if(!token && (request && request.method && request.method.toLowerCase().indexOf('api.login') != -1))
            toastr.warning("Please provide the user session token.", "Warning", {timeOut: 2000});
    }
}


function readValuesStart(){
	
	var request = [ 
		{
		id: "1",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".startStop"}
		},
		{
		id: "2",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".actFlowrate"}
		},
		{
		id: "3",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelScale"}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
		var startStop = JSON.parse(data)[0]["result"];
		var actFlowrate = JSON.parse(data)[1]["result"];
		var tankLevelScale = JSON.parse(data)[2]["result"];
		var img;
		
		if (startStop == false)
		{
			img = 0;
		}
		else
		{
			img = 1;
		}
		
		$('#plantStatus').attr({
			src: img_status_array[ img ].src,
			title: img_status_array[ img ].alt,
			alt: img_status_array[ img ].alt
		});
		
		$('#actFlowrate').html( actFlowrate );
		$('#tankLevelScale').html( tankLevelScale );
		$('#tankLevelScaleImg').width( tankLevelScale + "%");

	});           
	setTimeout(readValuesStart, 1000);
}


function readValuesOverview(){

	var request = [ 
		{
		id: "10",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".statusValveCPU"}
		},
		{
		id: "11",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelScale"}
		},
		{
		id: "12",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".actFlowrate"}
		},
		{
		id: "13",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevel"}
		},
		{
		id: "14",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelOverflow"}
		},
		{
		id: "15",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelMaximum"}
		},
		{
		id: "16",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelMidth"}
		},
		{
		id: "17",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelMinimum"}
		},
		{
		id: "18",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".tankLevelLack"}
		},
		{
		id: "19",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".alarmText"}
		},
		{
		id: "20",
		jsonrpc: "2.0",
		method: "PlcProgram.Read",
		params: {var: "\"Web2Plc\".alarmColor"}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
		var statusValveCPU1 = JSON.parse(data)[0]["result"];
		var tankLevelScale = JSON.parse(data)[1]["result"];
		var actFlowrate = JSON.parse(data)[2]["result"];
		var tankLevel = JSON.parse(data)[3]["result"];
		var tankLevelOverflow = JSON.parse(data)[4]["result"];
		var tankLevelMaximum = JSON.parse(data)[5]["result"];
		var tankLevelMidth = JSON.parse(data)[6]["result"];
		var tankLevelMinimum = JSON.parse(data)[7]["result"];
		var tankLevelLack = JSON.parse(data)[8]["result"];
		var alarmText = JSON.parse(data)[9]["result"];
		var alarmColor = JSON.parse(data)[10]["result"];
		var img;
		
		if (statusValveCPU1 == false)
		{
			img = 0;
		}
		else
		{
			img = 1;
		}
		
		$('#statusValveCPU').attr({
			src: img_valve_array[ img ].src,
			title: img_valve_array[ img ].alt,
			alt: img_valve_array[ img ].alt
		});
		
		$('#tankLevelScaleOverviewImg').height( tankLevelScale + "px");
		
		$('#actFlowrate').html( actFlowrate );
		$('#tankLevel').html( tankLevel );
		$('#tankLevelOverflow').html( tankLevelOverflow );
		$('#tankLevelMaximum').html( tankLevelMaximum );
		$('#tankLevelMidth').html( tankLevelMidth );
		$('#tankLevelMinimum').html( tankLevelMinimum );
		$('#tankLevelLack').html( tankLevelLack );
		
		
		$('#Alarm')
			.html( alarmArrayText[alarmText] )
			.css('color', alarmArrayColor[alarmColor]);

	}); 
	setTimeout(readValuesOverview, 1000);
}


function readValuesData(){
	
	var request = [];
		var iIndex = 0;
		for(i = 1; i <= 20; i++)
		{
			var myValue = {
				id: i + 25,
				jsonrpc: "2.0",
				method: "PlcProgram.Read",
				params: {var:  "\"DataBuffer\".data[" + i + "].value"} 
				};		
		
			request[iIndex++] = myValue;
		
			var myTimeStamp = {
				id: i + 45,
				jsonrpc: "2.0",
				method: "PlcProgram.Read",
				params: {var:  "\"DataBuffer\".data[" + i + "].timeStamp"} 
				};		
		
			request[iIndex++] = myTimeStamp;
		}
		
    postJsonRPC(hostAddress, request, userToken, function(data){
		var values = [];
		for(i = 0; i < 40; i++)
		{
			values[i] = JSON.parse(data)[i]["result"];
		}
		/* var data = values.data.split(","); */
		var select = "table[id='dataTable'] tbody tr";
		$(select).each(function(index){
			if(index < 20){
				$(this).find('td').eq(1).html( values[2*index+1] );
				$(this).find('td').eq(2).html( values[2*index] );
			}
			else{
				$(this).closest('tr').hide();
			}
		});
	});           
	setTimeout(readValuesData, 1000);
}


function writeStart(){
	
	var request = [
		{
		jsonrpc: "2.0",
		id: "100",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".start", value: true}
		},
		{
		id: "51",
		jsonrpc: "2.0",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".stop", value: false}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}

function writeStop(){
	
	var request = [
		{
		jsonrpc: "2.0",
		id: "101",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".start", value: false}
		},
		{
		id: "51",
		jsonrpc: "2.0",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".stop", value: true}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}

function writeReset(){
	
	var request = [
		{
		jsonrpc: "2.0",
		id: "102",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".reset", value: true}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}

function writeOpenValve(){
	
	var request = [
		{
		jsonrpc: "2.0",
		id: "103",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".openValve", value: true}
		},
		{
		id: "104",
		jsonrpc: "2.0",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".closeValve", value: false}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}

function writeCloseValve(){
	
	var request = [
		{
		jsonrpc: "2.0",
		id: "105",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".openValve", value: false}
		},
		{
		id: "106",
		jsonrpc: "2.0",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".closeValve", value: true}
		}
	];

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}

function writeFlowrate(flowrate){
	var request = 		{
		id: "110",
		jsonrpc: "2.0",
		method: "PlcProgram.Write",
		params: {var: "\"Web2Plc\".flowrate", value: parseInt(flowrate)}
		};

    postJsonRPC(hostAddress, request, userToken, function(data){
	});           
}


function pingPLC(){
    var request = {
		id: "999",
		jsonrpc: "2.0",
        method: "Api.Ping"
    };

    postJsonRPC(hostAddress, request, userToken, function(resp){  
         console.log(resp);
    });  
}





